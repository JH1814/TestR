x <- c(8,8,5,3,3,3,6,2,10)
mean(x)
median(x)

#comment
quantile(x, probs = c(0.25, 0.5, 0.75, 0.9))

x <- c(1,3,5,6,7,7,7,8,8,8,9,9,9,9,9,10,10,10,10,10)
mean(x)
median(x)
mode(x)

x <- c(12,-1,8,2,-10,0,-5,3,20,-2)
mean(x)
median(x)

